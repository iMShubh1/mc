import socket

HOST = "localhost"
PORT = 5000
FORMAT = "utf-8"

# Create TCP socket
server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Bind IP and port
server.bind((HOST, PORT))

# Wait for client
server.listen(1)

print("Waiting for connection...")

# Accept client
conn, addr = server.accept()

print("Connected by:", addr)

# Receive filename
filename = conn.recv(1024).decode(FORMAT)

print("Receiving file:", filename)

# Send acknowledgement
conn.send("Filename received".encode(FORMAT))

# Open file to save data
file = open(filename, "wb")

# Receive file data continuously
while True:

    data = conn.recv(1024)

    if not data:
        break

    file.write(data)

print("File received successfully")

# Close everything
file.close()
conn.close()
server.close()