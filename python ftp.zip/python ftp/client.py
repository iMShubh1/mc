import socket

HOST = "localhost"
PORT = 5000
FORMAT = "utf-8"

FILE_NAME = "abc.txt"

# Create TCP socket
client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# Connect to server
client.connect((HOST, PORT))

# Send filename
client.send(FILE_NAME.encode(FORMAT))

# Receive acknowledgement
msg = client.recv(1024).decode(FORMAT)

print(msg)

# Open file
file = open(FILE_NAME, "rb")

# Send file data continuously
while True:

    data = file.read(1024)

    if not data:
        break

    client.send(data)

print("File sent successfully")

# Close everything
file.close()
client.close()