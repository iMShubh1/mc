import socket, os

os.makedirs('received/', exist_ok=True)

conn, _ = socket.create_server(('0.0.0.0', 5001)).accept()

# Receive filename and size
filename = conn.recv(4096).decode(); conn.send(b"ACK")
filesize = int(conn.recv(4096).decode()); conn.send(b"ACK")

# Receive and save file
with open(f'received/{filename}', 'wb') as f:
    received = 0
    while received < filesize:
        chunk = conn.recv(4096)
        f.write(chunk)
        received += len(chunk)

print(f"Saved '{filename}' — {received} bytes")
conn.close()