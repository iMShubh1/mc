import socket, os

FILE = 'data.txt'

client = socket.create_connection(('127.0.0.1', 5001))

# Send filename and size
client.send(os.path.basename(FILE).encode()); client.recv(4096)
client.send(str(os.path.getsize(FILE)).encode()); client.recv(4096)

# Send file
with open(FILE, 'rb') as f:
    while chunk := f.read(4096):
        client.send(chunk)

print(f"Sent '{FILE}'")
client.close()